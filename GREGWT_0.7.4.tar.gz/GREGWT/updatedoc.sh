#!/bin/sh
Rscript -e "library(devtools); document()"
